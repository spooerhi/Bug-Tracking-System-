from django.apps import AppConfig


class BugappConfig(AppConfig):
    name = 'bugapp'
