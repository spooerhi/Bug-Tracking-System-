Manager
username - harish
pwd - harish

============
Admin 
username - admin
pwd - admin

Tester
username - ashok
pwd - ashok

Developer
username - sachin	
pwd - sachin